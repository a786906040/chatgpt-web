require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "AndLua"
import "android.content.Context"
import "android.view.animation.*"
import "android.animation.ObjectAnimator"
import "android.provider.Settings"
import "java.io.File"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.Typeface"
import "android.net.Uri"
import "android.content.Intent"
import "android.graphics.Color"
import "android.media.MediaPlayer"

activity.setTheme(R.Theme_Blue)
activity.setTitle("奥内幕")
activity.setContentView(loadlayout(layout))
隐藏标题栏()
沉浸状态栏()
窗口全屏()

url="https://sharechain.qq.com/34fd5adb085139000894002e093f72d7"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      内容=b:match("期数【(.-)】")
      qs.Text=""..内容
      内容=b:match("获取【(.-)】")
      hqqh.Text=""..内容

      内容=b:match("kj【(.-)】")
      kj.Text=""..内容
      内容=b:match("da【(.-)】")
      d1.Text=""..内容

      内容=b:match("kj1【(.-)】")
      kj1.Text=""..内容
      内容=b:match("db【(.-)】")
      d2.Text=""..内容

      内容=b:match("kj2【(.-)】")
      kj2.Text=""..内容
      内容=b:match("dc【(.-)】")
      d3.Text=""..内容

      内容=b:match("kj3【(.-)】")
      kj3.Text=""..内容
      内容=b:match("dd【(.-)】")
      d4.Text=""..内容

      内容=b:match("kj4【(.-)】")
      kj4.Text=""..内容
      内容=b:match("de【(.-)】")
      d5.Text=""..内容

      内容=b:match("kj5【(.-)】")
      kj5.Text=""..内容
      内容=b:match("df【(.-)】")
      d6.Text=""..内容

      内容=b:match("kj6【(.-)】")
      kj6.Text=""..内容
      内容=b:match("dg【(.-)】")
      d7.Text=""..内容

    end

  end
end)

function gm.onClick()
  跳转界面("gm")
end

function hq.onClick()
  跳转界面("t")
end
function jg.onClick()
  跳转界面("kjjg")
end
require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "kj"
import "AndLua"

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(kj))
隐藏标题栏()
沉浸状态栏()
窗口全屏()

llq={
  LinearLayout;
  orientation="vertical";
  {
    LuaWebView;
    id="Km";
    layout_width="match_parent";
    layout_height="match_parent";
  };
};

--打开网页
activity.setContentView(loadlayout(llq))
Km.loadUrl("https://x3.xn--c2be8bbg0fl3ewb.xn--i1b6b1a6a2e:8443/#/lottery?lotteryType=2")

require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "QM1"
import "AndLua"
activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(QM1))
隐藏标题栏()
沉浸状态栏()
窗口全屏()

url="https://sharechain.qq.com/34fd5adb085139000894002e093f72d7"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      内容=b:match("期数【(.-)】")
      qs.Text=""..内容
      内容=b:match("七马【(.-)】")
      hqqh.Text=""..内容

      内容=b:match("kj【(.-)】")
      kj.Text=""..内容
      内容=b:match("da【(.-)】")
      d1.Text=""..内容

      内容=b:match("kj1【(.-)】")
      kj1.Text=""..内容
      内容=b:match("db【(.-)】")
      d2.Text=""..内容

      内容=b:match("kj2【(.-)】")
      kj2.Text=""..内容
      内容=b:match("dc【(.-)】")
      d3.Text=""..内容

      内容=b:match("kj3【(.-)】")
      kj3.Text=""..内容
      内容=b:match("dd【(.-)】")
      d4.Text=""..内容

      内容=b:match("kj4【(.-)】")
      kj4.Text=""..内容
      内容=b:match("de【(.-)】")
      d5.Text=""..内容

      内容=b:match("kj5【(.-)】")
      kj5.Text=""..内容
      内容=b:match("df【(.-)】")
      d6.Text=""..内容

      内容=b:match("kj6【(.-)】")
      kj6.Text=""..内容
      内容=b:match("dg【(.-)】")
      d7.Text=""..内容

    end

  end
end)
function jg.onClick()
  跳转界面("kjjg")
end
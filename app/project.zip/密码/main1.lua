require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "Xl"

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(Xl))
require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "M"
import "AndLua"

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(M))
隐藏标题栏()

浏览器={
  LinearLayout;
  orientation="vertical";
  {
    LuaWebView;
    id="Km";
    layout_width="match_parent";
    layout_height="match_parent";
  };
};

--打开网页
  activity.setContentView(loadlayout(浏览器))
  Km.loadUrl("https://m.baidu.com/")

require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "Tq"
import "AndLua"
import "android.content.Context"
import "android.view.animation.*"
import "android.animation.ObjectAnimator"
import "android.provider.Settings"
import "java.io.File"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.Typeface"
import "android.net.Uri"
import "android.content.Intent"
import "android.graphics.Color"
import "android.media.MediaPlayer"

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(Tq))
隐藏标题栏()
沉浸状态栏()
窗口全屏()
进入.onClick=function()
  switch #密码.text
   case 0
    提示("请输入内部密码")--输入密码提示
   default
    switch 密码.text
     case"6666"--设置密码
      跳转界面("qm")--跳转七马显示
      关闭界面()
     default
      提示("密码错误")
    end
  end
end
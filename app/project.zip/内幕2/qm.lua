require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "QM1"
import "AndLua"
activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(QM1))
隐藏标题栏()

url="https://share.weiyun.com/VxBRYnCY"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("期数b【(.-)】")
      期数b.Text=""..期数

      期数=b:match("七马显示【(.-)】")
      七马显示.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/GwBnrAUz"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号【(.-)】")
      号.Text=""..期数

      期数=b:match("准【(.-)】")
      准.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/oQYWnVHb"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号1【(.-)】")
      号1.Text=""..期数

      期数=b:match("准1【(.-)】")
      准1.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/JC4BlcuU"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号2【(.-)】")
      号2.Text=""..期数

      期数=b:match("准2【(.-)】")
      准2.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/kvJjYu46"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号3【(.-)】")
      号3.Text=""..期数

      期数=b:match("准3【(.-)】")
      准3.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/NDUst8CS"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号4【(.-)】")
      号4.Text=""..期数

      期数=b:match("准4【(.-)】")
      准4.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/s1sbOFeM"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号5【(.-)】")
      号5.Text=""..期数

      期数=b:match("准5【(.-)】")
      准5.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/7j3UfRex"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号6【(.-)】")
      号6.Text=""..期数

      期数=b:match("准6【(.-)】")
      准6.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/59mEFvFe"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号7【(.-)】")
      号7.Text=""..期数

      期数=b:match("准7【(.-)】")
      准7.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/o29rdKe2"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号8【(.-)】")
      号8.Text=""..期数

      期数=b:match("准8【(.-)】")
      准8.Text=""..期数
    end

  end
end)
url="https://share.weiyun.com/O3zWqC3Z"
Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      期数=b:match("号9【(.-)】")
      号9.Text=""..期数

      期数=b:match("准9【(.-)】")
      准9.Text=""..期数
    end

  end
end)


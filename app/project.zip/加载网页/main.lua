require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "AndLua"

activity.setTheme(R.Theme_Blue)
activity.setTitle("加载网页")
activity.setContentView(loadlayout(layout))
隐藏标题栏()
沉浸状态栏()
窗口全屏()

浏览器={
  LinearLayout;
  orientation="vertical";
  {
    LuaWebView;
    id="Km";
    layout_width="match_parent";
    layout_height="match_parent";
  };
};
--去掉点击事件直接进去
function Jr.onClick--点击事件
activity.setContentView(loadlayout(浏览器))
Km.loadUrl("https://x3.xn--c2be8bbg0fl3ewb.xn--i1b6b1a6a2e:8443/#/lottery?lotteryType=2")
end
require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "AndLua"

activity.setTheme(R.Theme_Blue)
activity.setTitle("公告")
activity.setContentView(loadlayout(layout))

url="https://sharechain.qq.com/34fd5adb085139000894002e093f72d7","【","】","内容1"

Http.get(url,function(a,b)
  开关=b:match("开关【(.-)】")
  if a==200 then
    if 开关=="开" then
      内容=b:match("内容【(.-)】")
      内.Text=""..内容
      内容=b:match("内容3【(.-)】")
      内1.Text=""..内容
      内容=b:match("内容2【(.-)】")
      内2.Text=""..内容
      内容=b:match("内容4【(.-)】")
      内3.Text=""..内容
      内容=b:match("内容5【(.-)】")
      内4.Text=""..内容
      内容=b:match("内容6【(.-)】")
      内5.Text=""..内容
      内容=b:match("内容7【(.-)】")
      内6.Text=""..内容
      内容=b:match("内容8【(.-)】")
      内7.Text=""..内容
      内容=b:match("内容9【(.-)】")
      内8.Text=""..内容



    end

  end
end)
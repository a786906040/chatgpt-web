require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "M"
import "AndLua"

activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(M))
隐藏标题栏()

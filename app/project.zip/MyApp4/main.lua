require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "AndLua"

activity.setTheme(R.Theme_Blue)
activity.setTitle("MyApp4")
activity.setContentView(loadlayout(layout))

---跳转界面
function gm.onClick()
  跳转界面("main1")
end
